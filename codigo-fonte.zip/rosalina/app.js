/* Dados centralizados. Publicar somente após revisão dos serviços e identificação profissional. */
const site = {
  phone: '5519999994563',
  message: 'Olá, Dra. Rosalina! Conheci seu site e gostaria de saber mais sobre os atendimentos e agendar uma consulta.',
  cro: '',
  reviews: [], // Inserir apenas { text, author } verificados e autorizados.
  treatments: [
    ['Ortodontia', 'Converse sobre alinhamento dos dentes e acompanhamento ortodôntico, conforme avaliação individual.'],
    ['Ortopedia facial', 'Saiba mais sobre avaliação do desenvolvimento das estruturas da face e suas possibilidades de cuidado.'],
    ['Ortodontia estética', 'Conheça possibilidades ortodônticas com foco na discrição, de acordo com as necessidades do seu caso.'],
    ['Clareamento dental', 'Tire suas dúvidas sobre clareamento e a avaliação necessária antes de iniciar um procedimento.'],
    ['Laserterapia', 'Converse sobre as aplicações da laserterapia como recurso complementar, quando houver indicação.'],
    ['Consulta odontológica', 'Um primeiro encontro para avaliar a saúde bucal, ouvir suas dúvidas e orientar os próximos passos.'],
    ['Profilaxia dental', 'Saiba mais sobre limpeza profissional, prevenção e orientações para a sua rotina de higiene bucal.'],
    ['Extração do siso', 'Converse sobre a avaliação dos terceiros molares e as situações em que a extração pode ser indicada.']
  ]
};
const whatsappUrl = `https://wa.me/${site.phone}?text=${encodeURIComponent(site.message)}`;
function configureWhatsApp(root = document) {
  root.querySelectorAll('[data-whatsapp]').forEach(link => {
    link.href = whatsappUrl;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
  });
}
const grid = document.querySelector('#treatment-grid');
const treatmentIcons = [
  '<path d="M5 7v8c0 4 14 4 14 0V7M5 11h14M8 8v6m4-6v6m4-6v6"/>',
  '<path d="M15 20v-4c3-1 4-4 3-7a6 6 0 0 0-12 1v3l-2 2h4v5M14 7l2 1m-2 4h3"/>',
  '<path d="M4 12c0 8 16 8 16 0M5 9h14M8 7v7m4-7v7m4-7v7"/>',
  '<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5Z"/>',
  '<path d="m17 3 4 4-7 7-4-4ZM10 14l-6 6m2-8-3 1m9 5-1 3m-5-4-2-2"/>',
  '<path d="M7 4h10v16H7ZM9 4V2h6v2M9 10h6m-6 4h6m-6 3h4"/>',
  '<path d="M12 3S5 11 5 15a7 7 0 0 0 14 0c0-4-7-12-7-12ZM8 15c0 2 1 3 3 3"/>',
  '<path d="M8 3c2 0 2 1 4 1s2-1 4-1c5 0 3 9 2 13-1 5-3 6-4 0-1-4-3-4-4 0-1 6-3 5-4 0C5 12 3 3 8 3Z"/>'
];
site.treatments.forEach(([title, description], index) => {
  const card = document.createElement('article');
  card.className = `treatment reveal${index === 0 ? ' featured' : ''}`;
  const number = document.createElement('div'); number.className = 'treatment-number';
  number.textContent = String(index + 1).padStart(2, '0');
  const ornament = document.createElement('span'); ornament.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${treatmentIcons[index]}</svg>`; ornament.setAttribute('aria-hidden', 'true'); number.append(ornament);
  const heading = document.createElement('h3'); heading.textContent = title;
  const text = document.createElement('p'); text.textContent = description;
  const cta = document.createElement('a'); cta.dataset.whatsapp = ''; cta.textContent = 'Saiba mais'; cta.setAttribute('aria-label', `Saiba mais sobre ${title} pelo WhatsApp`);
  const arrow = document.createElement('span'); arrow.className = 'ui-arrow'; arrow.setAttribute('aria-hidden', 'true');
  arrow.innerHTML = '<svg viewBox="0 0 24 24" focusable="false"><path d="M6 18 18 6M6 6h12v12"/></svg>'; cta.append(arrow);
  card.append(number, heading, text, cta); grid.append(card);
});
configureWhatsApp();
const toggle = document.querySelector('.menu-toggle');
const menu = document.querySelector('#menu');
document.querySelector('.header-cta').setAttribute('aria-label', 'Agendar consulta pelo WhatsApp');
function closeMenu() {
  document.body.classList.remove('menu-open'); toggle.setAttribute('aria-expanded', 'false'); toggle.setAttribute('aria-label', 'Abrir menu');
  document.querySelector('main').inert = false;
  document.querySelector('footer').inert = false;
}
toggle.addEventListener('click', () => {
  const open = toggle.getAttribute('aria-expanded') !== 'true';
  document.body.classList.toggle('menu-open', open); toggle.setAttribute('aria-expanded', String(open)); toggle.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
  document.querySelector('main').inert = open;
  document.querySelector('footer').inert = open;
  if (open) menu.querySelector('a').focus();
});
menu.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
document.addEventListener('keydown', event => {
  if (!document.body.classList.contains('menu-open')) return;
  if (event.key === 'Escape') { closeMenu(); toggle.focus(); }
  if (event.key === 'Tab') {
    const elements = [...menu.querySelectorAll('a:not([hidden])'), document.querySelector('.header-cta'), toggle].filter(element => element.offsetParent !== null);
    const first = elements[0], last = elements.at(-1);
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }
});
window.matchMedia('(min-width: 801px)').addEventListener('change', event => { if (event.matches) closeMenu(); });
const header = document.querySelector('.header');
header.classList.toggle('scrolled', scrollY > 20);
window.addEventListener('scroll', () => header.classList.toggle('scrolled', scrollY > 20), { passive: true });
// Permanent automatic motion, explicitly requested for this version.
const motionEnabled = true;
let revealObserver;
const activeReveals = new Set();
const revealedElements = new WeakSet();
function animateReveal(element, delay = 0) {
  element.classList.add('visible');
  if (!motionEnabled || typeof element.animate !== 'function') return;
  const opacity = Number(getComputedStyle(element).opacity) || 1;
  let frames = [{opacity:0,transform:'translateY(22px)'},{opacity,transform:'none'}];
  let duration = 800;
  if (element.classList.contains('photo-mask')) {
    frames = [{opacity:0,clipPath:'inset(0 0 15% 0)',transform:'translateY(15px)'},{opacity,clipPath:'inset(0 0 0 0)',transform:'none'}];
    duration = 1050;
  } else if (element.classList.contains('section-rule') || element.classList.contains('about-photo-line')) {
    frames = [{opacity:0,transform:'scaleX(0)'},{opacity,transform:'scaleX(1)'}];
    duration = 950;
  } else if (element.classList.contains('about-monogram')) {
    const baseTransform = getComputedStyle(element).transform;
    const base = baseTransform === 'none' ? '' : baseTransform;
    frames = [{opacity:0,transform:`${base} translateY(5px) rotate(-4deg)`},{opacity,transform:baseTransform}];
    duration = 1300;
  }
  if (innerWidth <= 800) {
    // Keep content readable from the first frame, even during fast mobile scrolls.
    frames[0].opacity = opacity * .85;
    if (!element.classList.contains('about-monogram') && !element.classList.contains('section-rule') && !element.classList.contains('about-photo-line')) {
      frames[0].transform = 'translateY(10px)';
      if (element.classList.contains('photo-mask')) frames[0].clipPath = 'inset(0 0 3% 0)';
    }
    duration = Math.min(duration, 440);
    delay = Math.min(delay, 90);
  }
  try {
    // Backwards fill applies only during the delay. The underlying DOM stays visible.
    const animation = element.animate(frames,{duration,delay,easing:'cubic-bezier(.22,1,.36,1)',fill:'backwards'});
    activeReveals.add(animation);
    animation.finished.catch(() => {}).finally(() => activeReveals.delete(animation));
  } catch (_) { /* A failed effect must never hide content. */ }
}
function configureAutomaticMotion() {
  if (revealObserver) revealObserver.disconnect();
  activeReveals.forEach(animation => animation.cancel()); activeReveals.clear();
  document.documentElement.classList.remove('motion','motion-enabled','motion-disabled');
  document.documentElement.classList.toggle('motion-auto',motionEnabled);
  const elements = document.querySelectorAll('.reveal');
  if (!motionEnabled || !('IntersectionObserver' in window)) {
    elements.forEach(element => element.classList.add('visible'));
    return;
  }
  try {
    revealObserver = new IntersectionObserver(entries => entries.forEach(entry => {
      if (!entry.isIntersecting) { revealedElements.delete(entry.target); return; }
      if (revealedElements.has(entry.target)) return;
      const element = entry.target;
      revealedElements.add(element);
      let delay = 0;
      const cardIndex = [...grid.children].indexOf(element);
      if (cardIndex >= 0) delay = (cardIndex % (innerWidth <= 560 ? 1 : innerWidth <= 1100 ? 2 : 4)) * 80;
      else if (element.closest('.about-copy')) delay = [...document.querySelectorAll('.about-copy>.reveal')].indexOf(element) * 70;
      else if (element.closest('.about-heading')) delay = [...document.querySelectorAll('.about-heading>.reveal')].indexOf(element) * 80;
      else if (element.closest('.gallery-grid')) delay = [...document.querySelectorAll('.gallery-card')].indexOf(element) * 80;
      animateReveal(element,Math.max(0,delay));
    }),{threshold:0,rootMargin:'0px 0px 90px 0px'});
    elements.forEach(element => { if (!revealedElements.has(element)) revealObserver.observe(element); });
  } catch (_) { elements.forEach(element => element.classList.add('visible')); }
}
configureAutomaticMotion();

// Slow ambient motion uses the compositor and pauses outside the viewport.
const ambientAnimations = new Map();
const ambientVisible = new Set();
function syncAmbientMotion() {
  ambientAnimations.forEach((animation, element) => {
    if (!document.hidden && ambientVisible.has(element)) animation.play();
    else animation.pause();
  });
}
function addAmbientMotion(selector, frames, duration) {
  document.querySelectorAll(selector).forEach(element => {
    if (typeof element.animate !== 'function') return;
    try {
      const animation = element.animate(frames, {duration, iterations:Infinity, direction:'alternate', easing:'ease-in-out'});
      animation.pause();
      ambientAnimations.set(element, animation);
    } catch (_) { /* Keep the ordinary visible layout if animation is unavailable. */ }
  });
}
addAmbientMotion('.hero-visual img', [{transform:'scale(1.025) translateX(-.3%)'}, {transform:'scale(1.065) translateX(.3%)'}], 14000);
addAmbientMotion('.gallery-environment img, .gallery-detail img', [{transform:'scale(1.01)'}, {transform:'scale(1.045)'}], 11000);
addAmbientMotion('.about-panel-note', [{transform:'translateY(0)'}, {transform:'translateY(-5px)'}], 4000);
addAmbientMotion('.story-monogram', [{transform:'translateY(0) rotate(-2deg)'}, {transform:'translateY(-7px) rotate(2deg)'}], 7000);
addAmbientMotion('.hero-bottom>a span', [{transform:'translateY(-2px)'}, {transform:'translateY(5px)'}], 1600);
addAmbientMotion('.banner-orbit', [{transform:'rotate(-20deg)'}, {transform:'rotate(-8deg)'}], 14000);
if ('IntersectionObserver' in window) {
  const ambientObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) ambientVisible.add(entry.target);
      else ambientVisible.delete(entry.target);
    });
    syncAmbientMotion();
  });
  ambientAnimations.forEach((_, element) => ambientObserver.observe(element));
} else { ambientAnimations.forEach((_, element) => ambientVisible.add(element)); syncAmbientMotion(); }
document.addEventListener('visibilitychange', syncAmbientMotion);
document.querySelectorAll('.hero-enter').forEach((element,index) => animateReveal(element,index * 80));
// Scroll work is limited to one frame per event; there is no continuous JS loop.
let scrollFramePending = false;
function updateScrollMotion() {
  scrollFramePending = false;
  const height = document.documentElement.scrollHeight - innerHeight;
  document.documentElement.style.setProperty('--scroll-progress', String(height > 0 ? scrollY / height : 0));
  const portrait = document.querySelector('[data-parallax]');
  if (motionEnabled && innerWidth > 800 && portrait) {
    const shift = Math.min(10, Math.max(-10, scrollY * .025));
    portrait.style.setProperty('--portrait-shift', `${shift}px`);
  } else if (portrait) portrait.style.setProperty('--portrait-shift', '0px');
  const aboutArt = document.querySelector('.about-art');
  if (aboutArt) {
    const rect = aboutArt.getBoundingClientRect();
    const depth = motionEnabled && innerWidth > 800 ? Math.max(-6, Math.min(6, (innerHeight / 2 - rect.top - rect.height / 2) * .02)) : 0;
    aboutArt.style.setProperty('--about-depth', `${depth}px`);
  }
  const heroImage = document.querySelector('.hero-visual');
  if (heroImage) heroImage.style.setProperty('--hero-shift', !motionEnabled ? '0px' : `${Math.min(12, scrollY * .025)}px`);
}
function queueScrollMotion() {
  if (!scrollFramePending) { scrollFramePending = true; requestAnimationFrame(updateScrollMotion); }
}
window.addEventListener('scroll', queueScrollMotion, { passive: true });
window.addEventListener('resize', queueScrollMotion, { passive: true });

updateScrollMotion();
if ('IntersectionObserver' in window) {
  const sectionObserver = new IntersectionObserver(entries => {
    const current = entries.filter(entry => entry.isIntersecting).sort((a,b) => b.intersectionRatio - a.intersectionRatio)[0];
    if (!current) return;
    menu.querySelectorAll('a').forEach(link => {
      if (link.hash === `#${current.target.id}`) link.setAttribute('aria-current', 'location');
      else link.removeAttribute('aria-current');
    });
  }, { rootMargin: '-15% 0px -45% 0px', threshold: 0 });
  document.querySelectorAll('main>section[id]').forEach(section => sectionObserver.observe(section));
}
if (site.cro) { const registration = document.querySelector('#professional-registration'); registration.textContent = site.cro; registration.hidden = false; }
document.querySelector('#year').textContent = new Date().getFullYear();
if (site.reviews.length) {
  document.querySelector('#depoimentos').hidden = false;
  document.querySelector('.reviews-nav').hidden = false;
  const track = document.querySelector('.review-track');
  site.reviews.forEach(review => {
    const figure = document.createElement('figure'), quote = document.createElement('blockquote'), caption = document.createElement('figcaption');
    quote.textContent = review.text; caption.textContent = review.author; figure.append(quote, caption); track.append(figure);
  });
  const move = direction => track.scrollBy({ left: direction * (track.clientWidth + 24), behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
  document.querySelector('[data-review-prev]').addEventListener('click', () => move(-1));
  document.querySelector('[data-review-next]').addEventListener('click', () => move(1));
  track.addEventListener('keydown', event => { if (['ArrowLeft','ArrowRight'].includes(event.key)) { event.preventDefault(); move(event.key === 'ArrowLeft' ? -1 : 1); } });
  const updateReviews = () => {
    const index = Math.round(track.scrollLeft / (track.clientWidth + 24));
    document.querySelector('.review-status').textContent = `${index + 1} de ${site.reviews.length}`;
    document.querySelector('[data-review-prev]').disabled = index === 0;
    document.querySelector('[data-review-next]').disabled = index >= site.reviews.length - 1;
  };
  track.addEventListener('scroll', updateReviews, { passive: true }); updateReviews();
}
