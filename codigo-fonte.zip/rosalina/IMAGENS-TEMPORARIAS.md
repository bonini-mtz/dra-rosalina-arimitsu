# Imagens de apoio da versão 3

As imagens de ambiente desta versão são ilustrativas, criadas com ImageGen integrado (modo built-in) para aproximar a composição da referência enviada. O usuário autorizou imagens temporárias para substituição posterior. Elas não representam uma fotografia do consultório real. A fotografia da Dra. Rosalina continua sendo o arquivo fornecido pelo usuário, sem reconstrução por IA.

## Troca posterior

| Arquivo utilizado | Aplicação | Substituição indicada |
| --- | --- | --- |
| `assets/ambiente-hero-v3.webp` | Topo, detalhe da galeria e fundo da chamada final | Foto ampla do consultório, de preferência horizontal, com área livre à esquerda para o título |
| `assets/recepcao-v3.webp` | Galeria | Foto real da recepção ou sala de espera |
| `assets/rosalina-original.png` | Apresentação profissional | Retrato original em maior resolução, preservando o enquadramento |

Troque os arquivos ou atualize seus caminhos em `index.html` e `reference.css`. Remova as legendas de ambiente ilustrativo somente após inserir fotografias reais. Para atualizar o HTML independente de entrega, execute `work/package_site.py` a partir da raiz deste chat. O site modular nesta pasta pode ser servido diretamente, sem compilação.

As imagens de ambiente foram codificadas em WebP mantendo suas dimensões. O hero passou de 2.243.834 para 202.328 bytes e a recepção de 2.626.922 para 281.954 bytes. Os PNGs de origem foram preservados.

## Prompts utilizados

### Ambiente do topo

Create an original photorealistic architectural editorial photograph for an illustrative dental landing-page hero. Landscape wide 16:9 composition. A refined contemporary dental treatment room with a beautiful champagne ivory dental chair at center-right, tasteful dental light overhead, oak fluted wood wall on the left, restrained brushed champagne metal details, beige stone surfaces, large floor-to-ceiling windows on the right with soft daylight and blurred natural greenery. Warm indirect lighting, premium understated interior, exceptionally realistic materials and architectural detail, calm and welcoming. Eye-level wide angle professional interior photography, no people. Left third must be darker with quiet uncluttered warm wooden wall and enough negative space for white headline overlay; chair and windows dominate right half. No text, no logo, no watermark, no branding. Avoid futuristic equipment, exaggerated luxury, glossy plastic, blue clinical lighting, dramatic lens distortion. This is explicitly an illustrative concept environment, not a representation of an actual named clinic. Produce high-resolution clean photographic quality.

### Recepção

Original photorealistic architectural editorial photograph, landscape 16:9, high resolution. Illustrative contemporary dental clinic reception and waiting room, in the same restrained palette as a warm oak and ivory treatment room. Smooth beige stone reception desk on left, softly illuminated fluted oak wall behind it, blank wall with NO signage or letters, cream boucle armchairs on right, tall olive-green indoor plant, large daylight window and natural leafy greenery outside. Very elegant but comfortable, warm indirect lighting, calm daytime atmosphere, realistic professional interior photography. No people, no text, no logos, no watermark, no branding. This is explicitly an illustrative concept environment, not an actual named clinic. Refined premium understated design, no futuristic shapes, no glamorous gold, no blue lighting.
