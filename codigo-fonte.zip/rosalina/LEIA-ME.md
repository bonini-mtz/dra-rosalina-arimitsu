# Dra. Rosalina Arimitsu — versão atual

Landing page estática, sem instalação ou compilação de framework. Abra `index.html` ou sirva esta pasta em uma hospedagem estática. A página utiliza `site.css`, `app.js` e os arquivos de `assets/`. As folhas antigas de estilo permanecem apenas como histórico e não são carregadas.

## Contato

Telefone: **(19) 99999-4563**. Os quinze links de WhatsApp usam `5519999994563` com a mensagem solicitada, centralizada em `app.js`.

## Sobre e movimento

Os movimentos permanecem ativos automaticamente, sem botão, conforme a orientação mais recente. Essa versão mantém os efeitos mesmo quando o sistema solicita movimento reduzido. A navegação interna usa rolagem suave; as entradas se repetem ao retornar às seções. Imagens de ambiente têm zoom lento, e detalhes decorativos têm movimentos contínuos discretos. Os ciclos pausam fora da tela ou quando a aba está oculta, retomando automaticamente ao voltar.

O conteúdo continua visível se a animação falhar. A fotografia original, de 446 × 448 pixels, não foi retocada; o retrato é exibido em escala controlada. O relatório SOBRE-V5 descreve a composição anterior; sua descrição de preferência de movimento foi substituída por esta atualização.

## Antes de publicar

- Confirmar os oito serviços com a profissional e preencher o CRO em `site.cro`.
- Confirmar endereço e posicionamento do mapa.
- Inserir apenas depoimentos de origem e autorização verificadas em `site.reviews`. O componente permanece oculto enquanto não houver conteúdo.
- Convênios e horários específicos seguem pendentes de confirmação.
- Trocar os ambientes ilustrativos por fotografias reais, conforme `IMAGENS-TEMPORARIAS.md`.
- Após aprovação, remover `noindex,nofollow` e configurar URL canônica e imagem social da hospedagem.

Google Fonts e o mapa dependem de conexão. Fontes locais de fallback e o link independente de rotas continuam disponíveis. A entrega permanece local para revisão; não foi publicada.
